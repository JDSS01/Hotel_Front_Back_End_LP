import axios from 'axios';

// O endereço do seu Back-end
export const BASE_URL = 'http://localhost:8081/api';

// Interceptador global: antes de qualquer requisição sair, ele executa isso:
axios.interceptors.request.use(
  (config) => {
    // Pega o token que guardaremos no navegador
    const token = localStorage.getItem('token');
    
    // Se o token existir, cola ele no cabeçalho de Autorização
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);