// src/config/axios.js

// Aqui colocamos o endereço exato de onde o seu Spring Boot está rodando
export const BASE_URL = 'http://localhost:8081/api';