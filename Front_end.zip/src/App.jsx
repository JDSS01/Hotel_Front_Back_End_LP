import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';

// Importando as páginas
import Home from './pages/Home';
import CadastroHospede from './pages/CadastroHospede'; 
import CadastroQuarto from './pages/CadastroQuarto';
import ListagemHospedes from './pages/ListagemHospedes';
import ListagemQuartos from './pages/ListagemQuartos';
import CadastroPedido from './pages/CadastroPedido';
import ListagemPedidos from './pages/ListagemPedidos'; 
import ConsumoPedido from './pages/ConsumoPedido'; 
import ListagemReservas from './pages/ListagemReservas';
import CadastroReserva from './pages/CadastroReserva';
import ListagemFuncionarios from './pages/ListagemFuncionarios';
import CadastroFuncionario from './pages/CadastroFuncionario';
import ListagemCardapio from './pages/ListagemCardapio';
import CadastroCardapio from './pages/CadastroCardapio';

function App() {
  return (
    <Router>
      {/* Menu Superior - Adicionado link de Quartos */}
      <nav style={{ backgroundColor: '#2c3e50', padding: '15px', textAlign: 'center', marginBottom: '30px' }}>
        <Link to="/" style={{ color: 'white', marginRight: '15px', textDecoration: 'none', fontWeight: 'bold' }}>🏠 Início</Link>
        <Link to="/listagem-hospedes" style={{ color: 'white', marginRight: '15px', textDecoration: 'none', fontWeight: 'bold' }}>📋 Hóspedes</Link>
        <Link to="/listagem-quartos" style={{ color: 'white', marginRight: '15px', textDecoration: 'none', fontWeight: 'bold' }}>🛏️ Quartos</Link>
        <Link to="/reservas" style={{ color: 'white', marginRight: '15px', textDecoration: 'none', fontWeight: 'bold' }}>📅 Reservas</Link>
        <Link to="/checkin" style={{ color: 'white', marginRight: '15px', textDecoration: 'none', fontWeight: 'bold' }}>➕ Check-in</Link>
        <Link to="/painel" style={{ color: 'white', marginRight: '15px', textDecoration: 'none', fontWeight: 'bold' }}>🛎️ Check-out</Link>
        <Link to="/pedidos" style={{ color: 'white', marginRight: '15px', textDecoration: 'none', fontWeight: 'bold' }}>🍽️ Cardápio</Link>
        <Link to="/funcionarios" style={{ color: 'white', textDecoration: 'none', fontWeight: 'bold' }}>👷 Funcionários</Link>
      </nav>
      
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/home" element={<Home />} />
        
        <Route path="/painel" element={<ListagemPedidos />} />

        <Route path="/listagem-hospedes" element={<ListagemHospedes />} />
        <Route path="/cadastro-hospedes" element={<CadastroHospede />} />
        <Route path="/cadastro-hospedes/:idParam" element={<CadastroHospede />} />

        <Route path="/listagem-quartos" element={<ListagemQuartos />} />
        <Route path="/cadastro-quartos" element={<CadastroQuarto />} />
        <Route path="/cadastro-quartos/:idParam" element={<CadastroQuarto />} />

        <Route path="/checkin" element={<CadastroPedido />} />
        <Route path="/checkin/:idParam" element={<CadastroPedido />} />
        <Route path="/consumo/:idParam" element={<ConsumoPedido />} />

        <Route path="/reservas" element={<ListagemReservas />} />
        <Route path="/cadastro-reservas" element={<CadastroReserva />} />
        <Route path="/cadastro-reservas/:idParam" element={<CadastroReserva />} />
        
        <Route path="/funcionarios" element={<ListagemFuncionarios />} />
        <Route path="/cadastro-funcionarios" element={<CadastroFuncionario />} />
        <Route path="/cadastro-funcionarios/:idParam" element={<CadastroFuncionario />} />

        <Route path="/pedidos" element={<ListagemCardapio />} />
        <Route path="/cadastro-cardapio" element={<CadastroCardapio />} />
        <Route path="/cadastro-cardapio/:tipo/:idParam" element={<CadastroCardapio />} />
      </Routes>
    </Router>
  );
}

export default App;