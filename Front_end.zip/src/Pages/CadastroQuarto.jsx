import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

import Stack from '@mui/material/Stack';

import Card from '../components/card';
import FormGroup from '../components/form-group';
import { mensagemSucesso, mensagemErro } from '../components/toastr';

import '../custom.css';

import axios from 'axios';
import { BASE_URL } from '../config/axios';

function CadastroQuarto() {
  const { idParam } = useParams();
  const navigate = useNavigate();

  const baseURL = `${BASE_URL}/quartos`;

  const [id, setId] = useState('');
  const [numero, setNumero] = useState('');
  const [tipo, setTipo] = useState('');
  const [capacidade, setCapacidade] = useState('');
  const [valorDiaria, setValorDiaria] = useState('');

  const [dados, setDados] = React.useState([]);

  function inicializar() {
    if (idParam == null) {
      setId('');
      setNumero('');
      setTipo('');
      setCapacidade('');
      setValorDiaria('');
    } else {
      setId(dados.id);
      setNumero(dados.numero);
      setTipo(dados.tipo);
      setCapacidade(dados.capacidade);
      setValorDiaria(dados.valorDiaria);
    }
  }

  async function salvar() {
    let data = { id, numero, tipo, capacidade, valorDiaria };
    data = JSON.stringify(data);
    
    if (idParam == null) {
      await axios
        .post(baseURL, data, {
          headers: { 'Content-Type': 'application/json' },
        })
        .then(function (response) {
          mensagemSucesso(`Quarto ${numero} cadastrado com sucesso!`);
          navigate(`/listagem-quartos`);
        })
        .catch(function (error) {
          mensagemErro(error.response.data);
        });
    } else {
      await axios
        .put(`${baseURL}/${idParam}`, data, {
          headers: { 'Content-Type': 'application/json' },
        })
        .then(function (response) {
          mensagemSucesso(`Quarto ${numero} alterado com sucesso!`);
          navigate(`/listagem-quartos`);
        })
        .catch(function (error) {
          mensagemErro(error.response.data);
        });
    }
  }

  async function buscar() {
    await axios.get(`${baseURL}/${idParam}`).then((response) => {
      setDados(response.data);
    });
    setId(dados.id);
    setNumero(dados.numero);
    setTipo(dados.tipo);
    setCapacidade(dados.capacidade);
    setValorDiaria(dados.valorDiaria);
  }

  useEffect(() => {
    if (idParam) {
      buscar(); // eslint-disable-next-line
    }
  }, [idParam]);

  return (
    <div className='container'>
      <Card title='Cadastro de Quarto'>
        <div className='row'>
          <div className='col-lg-12'>
            <div className='bs-component'>
              <FormGroup label='Número do Quarto: *' htmlFor='inputNumero'>
                <input
                  type='text'
                  id='inputNumero'
                  value={numero}
                  className='form-control'
                  name='numero'
                  onChange={(e) => setNumero(e.target.value)}
                />
              </FormGroup>
              <FormGroup label='Tipo (ex: Casal, Solteiro): *' htmlFor='inputTipo'>
                <input
                  type='text'
                  id='inputTipo'
                  value={tipo}
                  className='form-control'
                  name='tipo'
                  onChange={(e) => setTipo(e.target.value)}
                />
              </FormGroup>
              <FormGroup label='Capacidade (Pessoas): *' htmlFor='inputCapacidade'>
                <input
                  type='number'
                  id='inputCapacidade'
                  value={capacidade}
                  className='form-control'
                  name='capacidade'
                  onChange={(e) => setCapacidade(e.target.value)}
                />
              </FormGroup>
              <FormGroup label='Valor da Diária (R$): *' htmlFor='inputValorDiaria'>
                <input
                  type='number'
                  step='0.01'
                  id='inputValorDiaria'
                  value={valorDiaria}
                  className='form-control'
                  name='valorDiaria'
                  onChange={(e) => setValorDiaria(e.target.value)}
                />
              </FormGroup>
              
              <Stack spacing={1} padding={1} direction='row'>
                <button
                  onClick={salvar}
                  type='button'
                  className='btn btn-success'
                >
                  Salvar
                </button>
                <button
                  onClick={() => navigate('/listagem-quartos')}
                  type='button'
                  className='btn btn-danger'
                >
                  Cancelar
                </button>
              </Stack>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}

export default CadastroQuarto;