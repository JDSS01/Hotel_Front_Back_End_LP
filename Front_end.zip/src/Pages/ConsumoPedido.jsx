import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';
import { BASE_URL } from '../config/axios';
import Card from '../components/card';
import FormGroup from '../components/form-group';
import { mensagemSucesso, mensagemErro } from '../components/toastr';
import Stack from '@mui/material/Stack';

function ConsumoPedido() {
  const { idParam } = useParams();
  const navigate = useNavigate();
  
  const [pedido, setPedido] = useState(null);
  
  // Listas vindas do banco (Cardápio)
  const [listaItens, setListaItens] = useState([]);
  const [listaServicos, setListaServicos] = useState([]);

  // O que o usuário selecionou no Dropdown
  const [itemSelecionado, setItemSelecionado] = useState('');
  const [servicoSelecionado, setServicoSelecionado] = useState('');

  useEffect(() => {
    buscarDados();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [idParam]);

  const buscarDados = async () => {
    try {
      // 1. Busca o pedido atual para saber o que já foi consumido
      const resPedido = await axios.get(`${BASE_URL}/pedidos/${idParam}`);
      setPedido(resPedido.data);

      // 2. Busca o cardápio de Itens e Serviços disponíveis no hotel
      const resItens = await axios.get(`${BASE_URL}/itens`);
      const resServicos = await axios.get(`${BASE_URL}/servicos`);
      
      setListaItens(resItens.data);
      setListaServicos(resServicos.data);
    } catch (error) {
      mensagemErro("Erro ao carregar dados. Verifique se os Controllers de Item e Servico existem no backend.");
    }
  };

  const adicionarItem = async () => {
    if (!itemSelecionado) return mensagemErro("Selecione um item primeiro!");

    // Adiciona o novo item (só o ID) na lista de itens que já existem no pedido
    const payload = {
      ...pedido,
      itens: [...(pedido.itens || []), { id: Number(itemSelecionado) }]
    };

    try {
      await axios.put(`${BASE_URL}/pedidos/${idParam}`, payload);
      mensagemSucesso("Item adicionado à conta do quarto!");
      setItemSelecionado(''); // Limpa o select
      buscarDados(); // Atualiza a tela com o novo item
    } catch (error) {
      mensagemErro("Erro ao adicionar item.");
    }
  };

  const adicionarServico = async () => {
    if (!servicoSelecionado) return mensagemErro("Selecione um serviço primeiro!");

    const payload = {
      ...pedido,
      servicos: [...(pedido.servicos || []), { id: Number(servicoSelecionado) }]
    };

    try {
      await axios.put(`${BASE_URL}/pedidos/${idParam}`, payload);
      mensagemSucesso("Serviço adicionado à conta do quarto!");
      setServicoSelecionado('');
      buscarDados();
    } catch (error) {
      mensagemErro("Erro ao adicionar serviço.");
    }
  };

  if (!pedido) return <div className="container">Carregando dados da estadia...</div>;

  return (
    <div className='container'>
      <Card title={`Lançar Consumo - Quarto ${pedido.quarto?.numero} (${pedido.hospede?.nome})`}>
        
        <div className="row">
          {/* LADO ESQUERDO: ADICIONAR PRODUTOS/SERVIÇOS */}
          <div className="col-md-6" style={{ borderRight: '1px solid #eee', paddingRight: '20px' }}>
            <h4 style={{ color: '#2980b9' }}>Adicionar à Conta</h4>
            
            <div style={{ marginTop: '20px', padding: '15px', backgroundColor: '#f8f9fa', borderRadius: '8px' }}>
              <FormGroup label='Adicionar Item (Frigobar/Restaurante):' htmlFor='selectItem'>
                <Stack direction="row" spacing={1}>
                  <select 
                    className='form-control' 
                    id='selectItem' 
                    value={itemSelecionado} 
                    onChange={(e) => setItemSelecionado(e.target.value)}
                  >
                    <option value=''>-- Selecione o Item --</option>
                    {listaItens.map(item => (
                      <option key={item.id} value={item.id}>
                        {item.nome} - R$ {item.valor?.toFixed(2)}
                      </option>
                    ))}
                  </select>
                  <button className="btn btn-success" onClick={adicionarItem}>+</button>
                </Stack>
              </FormGroup>
            </div>

            <div style={{ marginTop: '20px', padding: '15px', backgroundColor: '#f8f9fa', borderRadius: '8px' }}>
              <FormGroup label='Adicionar Serviço (Lavanderia/Massagem):' htmlFor='selectServico'>
                <Stack direction="row" spacing={1}>
                  <select 
                    className='form-control' 
                    id='selectServico' 
                    value={servicoSelecionado} 
                    onChange={(e) => setServicoSelecionado(e.target.value)}
                  >
                    <option value=''>-- Selecione o Serviço --</option>
                    {listaServicos.map(serv => (
                      <option key={serv.id} value={serv.id}>
                        {serv.nome || serv.descricao} - R$ {serv.valor?.toFixed(2)}
                      </option>
                    ))}
                  </select>
                  <button className="btn btn-success" onClick={adicionarServico}>+</button>
                </Stack>
              </FormGroup>
            </div>
          </div>

          {/* LADO DIREITO: EXTRATO DO QUE JÁ FOI CONSUMIDO */}
          <div className="col-md-6" style={{ paddingLeft: '20px' }}>
            <h4 style={{ color: '#27ae60' }}>Extrato Atual do Quarto</h4>
            
            <div style={{ marginTop: '20px' }}>
              <h5>📦 Itens Consumidos</h5>
              {(!pedido.itens || pedido.itens.length === 0) ? (
                <p style={{ color: '#95a5a6', fontSize: '14px' }}>Nenhum item consumido.</p>
              ) : (
                <ul className="list-group">
                  {pedido.itens.map((item, index) => (
                    <li key={`item-${index}`} className="list-group-item d-flex justify-content-between align-items-center">
                      {item.nome}
                      <span className="badge bg-primary rounded-pill">R$ {item.valor?.toFixed(2)}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div style={{ marginTop: '20px' }}>
              <h5>🛎️ Serviços Utilizados</h5>
              {(!pedido.servicos || pedido.servicos.length === 0) ? (
                <p style={{ color: '#95a5a6', fontSize: '14px' }}>Nenhum serviço solicitado.</p>
              ) : (
                <ul className="list-group">
                  {pedido.servicos.map((serv, index) => (
                    <li key={`serv-${index}`} className="list-group-item d-flex justify-content-between align-items-center">
                      {serv.nome || serv.descricao}
                      <span className="badge bg-info rounded-pill">R$ {serv.valor?.toFixed(2)}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>

        <Stack spacing={1} padding={2} direction='row' justifyContent="center" style={{ marginTop: '30px', borderTop: '1px solid #eee', paddingTop: '20px' }}>
          <button onClick={() => navigate('/painel')} type='button' className='btn btn-secondary'>
            ⬅ Voltar para o Painel
          </button>
        </Stack>

      </Card>
    </div>
  );
}

export default ConsumoPedido;