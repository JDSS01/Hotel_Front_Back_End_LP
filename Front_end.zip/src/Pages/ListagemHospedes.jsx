import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { BASE_URL } from '../config/axios';
import Card from '../components/card';
import { mensagemSucesso, mensagemErro } from '../components/toastr';

function ListagemHospedes() {
  const navigate = useNavigate();
  const [hospedes, setHospedes] = useState([]);

  const buscarHospedes = async () => {
    try {
      const response = await axios.get(`${BASE_URL}/hospedes`);
      setHospedes(response.data);
    } catch (error) {
      mensagemErro('Erro ao buscar a lista de hóspedes.');
    }
  };

  useEffect(() => {
    buscarHospedes();
  }, []);

  const excluirHospede = async (id) => {
    if (window.confirm('Tem certeza que deseja excluir este hóspede?')) {
      try {
        await axios.delete(`${BASE_URL}/hospedes/${id}`);
        mensagemSucesso('Hóspede excluído com sucesso!');
        buscarHospedes(); // Atualiza a tabela na mesma hora
      } catch (error) {
        mensagemErro('Erro ao excluir. Este hóspede pode ter uma reserva ou pedido ativo no sistema.');
      }
    }
  };

  return (
    <div className='container'>
      <Card title='Lista de Hóspedes'>
        
        <div style={{ marginBottom: '20px' }}>
          {/* BOTÃO RENOMEADO AQUI */}
          <button className="btn btn-success" onClick={() => navigate('/cadastro-hospedes')}>
            Cadastrar Hospede
          </button>
        </div>

        <table className="table-custom" style={{ width: '100%', textAlign: 'left' }}>
          <thead>
            <tr>
              {/* COLUNA DE ID REMOVIDA DAQUI */}
              <th>Nome</th>
              <th>CPF</th>
              <th>Telefone</th>
              <th>Endereço</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
            {hospedes.length === 0 ? (
              <tr>
                <td colSpan="5" style={{ textAlign: 'center', padding: '20px' }}>
                  Nenhum hóspede cadastrado.
                </td>
              </tr>
            ) : (
              hospedes.map((hospede) => (
                <tr key={hospede.id}>
                  {/* INFORMAÇÃO DE ID REMOVIDA DAQUI */}
                  <td>{hospede.nome}</td>
                  <td>{hospede.cpf}</td>
                  <td>{hospede.telefone}</td>
                  <td>{hospede.endereco}</td>
                  <td>
                    <button 
                      className="btn btn-primary" 
                      style={{ marginRight: '10px', backgroundColor: '#3498db' }}
                      onClick={() => navigate(`/cadastro-hospedes/${hospede.id}`)}>
                      Editar
                    </button>
                    <button 
                      className="btn btn-danger" 
                      style={{ backgroundColor: '#e74c3c' }}
                      onClick={() => excluirHospede(hospede.id)}>
                      Excluir
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>

      </Card>
    </div>
  );
}

export default ListagemHospedes;