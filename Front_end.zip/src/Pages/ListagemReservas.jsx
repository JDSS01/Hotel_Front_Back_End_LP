import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { BASE_URL } from '../config/axios';
import Card from '../components/card';
import { mensagemSucesso, mensagemErro } from '../components/toastr';

function ListagemReservas() {
  const navigate = useNavigate();
  const [reservas, setReservas] = useState([]);

  const buscarReservas = async () => {
    try {
      const response = await axios.get(`${BASE_URL}/reservas`);
      setReservas(response.data);
    } catch (error) {
      mensagemErro('Erro ao buscar a lista de reservas.');
    }
  };

  useEffect(() => {
    buscarReservas();
  }, []);

  const excluirReserva = async (id) => {
    if (window.confirm('Tem certeza que deseja cancelar/excluir esta reserva?')) {
      try {
        await axios.delete(`${BASE_URL}/reservas/${id}`);
        mensagemSucesso('Reserva excluída com sucesso!');
        buscarReservas(); 
      } catch (error) {
        mensagemErro('Erro ao excluir a reserva.');
      }
    }
  };

  const formatarData = (dataStr) => {
    if (!dataStr) return '';
    const data = new Date(dataStr);
    return data.toLocaleDateString('pt-BR');
  };

  return (
    <div className='container'>
      <Card title='Gerenciamento de Reservas'>
        
        <div style={{ marginBottom: '20px' }}>
          <button className="btn btn-success" onClick={() => navigate('/cadastro-reservas')}>
            + Nova Reserva
          </button>
        </div>

        <table className="table-custom" style={{ width: '100%', textAlign: 'left' }}>
          <thead>
            <tr>
              <th>Hóspede</th>
              <th>Quarto</th>
              <th>Entrada Prevista</th>
              <th>Saída Prevista</th>
              <th>Status</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
            {reservas.length === 0 ? (
              <tr>
                <td colSpan="6" style={{ textAlign: 'center', padding: '20px' }}>
                  Nenhuma reserva encontrada no sistema.
                </td>
              </tr>
            ) : (
              reservas.map((reserva) => (
                <tr key={reserva.id}>
                  <td>{reserva.hospede?.nome}</td>
                  <td>{reserva.quarto?.numero} ({reserva.quarto?.tipo})</td>
                  <td>{formatarData(reserva.dataEntrada)}</td>
                  <td>{formatarData(reserva.dataSaida)}</td>
                  <td>
                    <span className={`badge ${reserva.status === 'CONFIRMADA' ? 'bg-success' : reserva.status === 'CANCELADA' ? 'bg-danger' : 'bg-warning text-dark'}`}>
                      {reserva.status || 'PENDENTE'}
                    </span>
                  </td>
                  <td>
                    <button 
                      className="btn btn-primary" 
                      style={{ marginRight: '10px', backgroundColor: '#3498db' }}
                      onClick={() => navigate(`/cadastro-reservas/${reserva.id}`)}>
                      Editar
                    </button>
                    <button 
                      className="btn btn-danger" 
                      style={{ backgroundColor: '#e74c3c' }}
                      onClick={() => excluirReserva(reserva.id)}>
                      Excluir
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

export default ListagemReservas;