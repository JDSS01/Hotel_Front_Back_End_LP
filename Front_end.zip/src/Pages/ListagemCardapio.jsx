import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { BASE_URL } from '../config/axios';
import Card from '../components/card';
import { mensagemSucesso, mensagemErro } from '../components/toastr';

function ListagemCardapio() {
  const navigate = useNavigate();
  const [itens, setItens] = useState([]);
  const [servicos, setServicos] = useState([]);

  useEffect(() => {
    buscarDados();
  }, []);

  const buscarDados = async () => {
    try {
      const resItens = await axios.get(`${BASE_URL}/itens`);
      const resServicos = await axios.get(`${BASE_URL}/servicos`);
      setItens(resItens.data);
      setServicos(resServicos.data);
    } catch (error) {
      mensagemErro('Erro ao buscar o cardápio do hotel.');
    }
  };

  const excluirItem = async (id) => {
    if (window.confirm('Tem certeza que deseja excluir este item?')) {
      try {
        await axios.delete(`${BASE_URL}/itens/${id}`);
        mensagemSucesso('Item excluído com sucesso!');
        buscarDados();
      } catch (error) { mensagemErro('Erro ao excluir item.'); }
    }
  };

  const excluirServico = async (id) => {
    if (window.confirm('Tem certeza que deseja excluir este serviço?')) {
      try {
        await axios.delete(`${BASE_URL}/servicos/${id}`);
        mensagemSucesso('Serviço excluído com sucesso!');
        buscarDados();
      } catch (error) { mensagemErro('Erro ao excluir serviço.'); }
    }
  };

  return (
    <div className='container'>
      <Card title='Gerenciamento de Itens e Serviços'>
        <div style={{ marginBottom: '30px', textAlign: 'center' }}>
          <button className="btn btn-success" onClick={() => navigate('/cadastro-cardapio')} style={{ padding: '10px 30px', borderRadius: '25px', fontWeight: 'bold' }}>
            + Adicionar ao Cardápio
          </button>
        </div>
        
        <div className="row">
          {/* Tabela de Itens */}
          <div className="col-md-6">
            <h4 style={{ color: '#2c3e50', fontWeight: 'bold', borderBottom: '2px solid #3498db', paddingBottom: '10px' }}>🍔 Itens (Frigobar/Restaurante)</h4>
            <table className="table-custom" style={{ width: '100%', textAlign: 'left', marginTop: '15px' }}>
              <thead><tr style={{ backgroundColor: '#ecf0f1' }}><th>Nome</th><th>Valor (R$)</th><th>Ações</th></tr></thead>
              <tbody>
                {itens.length === 0 ? (<tr><td colSpan="3" style={{ textAlign: 'center' }}>Nenhum item.</td></tr>) : (
                  itens.map((item) => (
                    <tr key={item.id}>
                      <td>{item.nome}</td>
                      <td style={{ color: '#27ae60', fontWeight: 'bold' }}>R$ {item.valor?.toFixed(2)}</td>
                      <td>
                        <button className="btn btn-primary btn-sm" style={{ marginRight: '5px' }} onClick={() => navigate(`/cadastro-cardapio/item/${item.id}`)}>Editar</button>
                        <button className="btn btn-danger btn-sm" onClick={() => excluirItem(item.id)}>Excluir</button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Tabela de Serviços */}
          <div className="col-md-6">
            <h4 style={{ color: '#2c3e50', fontWeight: 'bold', borderBottom: '2px solid #e67e22', paddingBottom: '10px' }}>🛎️ Serviços (Lavanderia/Outros)</h4>
            <table className="table-custom" style={{ width: '100%', textAlign: 'left', marginTop: '15px' }}>
              <thead><tr style={{ backgroundColor: '#ecf0f1' }}><th>Nome</th><th>Valor (R$)</th><th>Ações</th></tr></thead>
              <tbody>
                {servicos.length === 0 ? (<tr><td colSpan="3" style={{ textAlign: 'center' }}>Nenhum serviço.</td></tr>) : (
                  servicos.map((servico) => (
                    <tr key={servico.id}>
                      <td>{servico.nome}</td>
                      <td style={{ color: '#27ae60', fontWeight: 'bold' }}>R$ {servico.valor?.toFixed(2)}</td>
                      <td>
                        <button className="btn btn-primary btn-sm" style={{ marginRight: '5px' }} onClick={() => navigate(`/cadastro-cardapio/servico/${servico.id}`)}>Editar</button>
                        <button className="btn btn-danger btn-sm" onClick={() => excluirServico(servico.id)}>Excluir</button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </Card>
    </div>
  );
}
export default ListagemCardapio;