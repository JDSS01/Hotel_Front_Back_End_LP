package com.example.api;

// Corrigido de "extendes" para "extends"
public class RegraNegocioException extends RuntimeException {

    public RegraNegocioException(String mensagem) {
        super(mensagem);
    }
}